
#ifndef MobaTools_h
#define MobaTools_h
#include "Arduino.h"

// -----------------------------------------------------------------------
// Class "Ampelschaltung"                                      KONSTRUKTOR
// Einfache Ampelschaltung f�r z.B. Modelleisenbahnen usw.
//
// Eigenschaften / Methoden:
//   - Nachtmodus auf manuelle Anforderung 
//   - Tagesmodus auf manuelle Anforderung 
//   - Fussg�nger-�berweg auf Gr�n nur wenn Anforderung vorliegt
//   - Fussg�nger-�berweg mit "Warten" kennzeichnet kommende Freigabe
//   - Wenn �berweg UND Nachtmodus angefordert wurde, wird alles dunkel geschaltet
//   - Im Nachtmodus blinkt nur gelbes Warnlicht
//   - Fussg�nger-Anforderung wird im Nachtmodus blockiert
//   - Nachtmodus (wenn angefordert) am Ende einer Gr�nphase
//
// Parameter:
//   Ampelschaltung
//   {
//     byte  >  Pin LED "Rot"   (Stra�e) / Mind. 10 Sek.
//     byte  >  Pin LED "Gelb"  (Stra�e) / Mind. 1 Sek.
//     byte  >  Pin LED "Gr�n"  (Stra�e) / Mind. 5 Sek.
//     byte  >  Pin LED (gelb)  (Signalisiert "Tag-/Nachtmodus" angefordert)
//     word  >  Sekunden Rot-Phase      
//     word  >  Sekunden RotGelb-Phase  
//     word  >  Sekunden Gr�n-Phase
//     word  >  Sekunden Gelb-Phase
//     byte  >  Pin LED "Wei�"  (Fu�g�nger "Warten")
//     byte  >  Pin LED "Rot"   (Fu�g�nger)
//     byte  >  Pin LED "Gr�n"  (Fu�g�nger)
//     byte  >  Pin LED (gelb)  (Signalisiert "Fug�nger-Modus" angefordert)
//   }
// 

class Ampelschaltung
{
  public:
    Ampelschaltung( byte, byte, byte, byte, word, word, word, word, byte, byte, byte, byte );
    void begin();
    void Run();
    void Nachtmodus();
    void Fussgaenger();
    
  private:
    // Ampelphasen
    enum
    { 
      START, 
      ROT, 
      ROTGELB, 
      GRUEN, 
      GELB, 
      NACHT, 
      OFF, 
      ON 
    };
    
    // Hauptstra�e
    byte _pinR;          //  Pin ROT
    byte _pinY;          //  Pin Gelb
    byte _pinG;          //  Pin Gr�n
    byte _pinAN;         //  Pin Anforderung Nachtmodus
    
    word _secR;          //  Sekunden Auto Rot
    word _secRY;         //  Sekunden Auto Rot-Gelb
    word _secG;          //  Sekunden Auto Gr�n
    word _secY;          //  Sekunden Auto Gelb
    
    byte _phase;         //  Aktuelle Phase
    word _scount;        //  temp. Sekunden-Z�hler
    unsigned long _mS;   //  temp. Millis bei "Ampel Stra�e"
    
    byte _last;          //  Phase, vorhergehend
    byte _next;          //  Phase, n�chste
    byte _lastmod;       //  Modus, vorhergehend
    byte _modus;         //  Modus, aktuell
    boolean _anford;     //  Anforderung Nachtmodus
    
    // Fussgaenger�berweg
    byte _pinWe;         //  Pin Weiss "Warten"
    byte _pinRo;         //  Pin Rot
    byte _pinGr;         //  Pin Gr�n
    byte _pinAF;         //  Pin Anforderung Fu�g�nger
    
    unsigned long _mf;   //  Millis bei "Ampel Fu�g�nger"

    boolean _fussford;   //  Fu�g�nger-Modus angefordert
    boolean _fussaktiv;  //  Fu�g�nger-Modus aktiv?
    boolean _gruen;      //  Fu�g�nger ist Gr�n?
    boolean _fussblock;  //  Blockierung Fu�g�nger-Modus (nachts)

    // Private Methoden
    void FussGruen();    //  Schaltet "Fu�g�nger gr�n" wenn angefordert und Autos = Rot begonnen hat
    byte RotPhase();     //  Abfrage der Phase Autos = Rot, wAnn "Fu�g�nger" auf Gr�n oder Rot gehen soll 
    void FussRun();      //  "Warten" blinkt (nur) wenn angefordert
};

// -----------------------------------------------------------------------
// Class "Warnblinker"                                         KONSTRUKTOR
// Blinker-/Flasher-Variante f�r beliebige Zwecke
//
// Eigenschaften / Methoden:
//   - Einsatz auf z.B. Modellbahnen f�r "Polizei auf Abruf"
//   - Herzschlag in einem Programm, gegen delay()...
//   - Mehrfach Impulsgeber wie z.B. ||__||__||__ oder |||_|||_|||_
//   - Einstellbar auf kontinuierliches Blinken gem�� Vorgabe
//   - Manueller Start zu einem beliebigen Zeitpunkt
//   - Manueller Stopp zu einem beliebigen Zeitpunkt
//
// Parameter:
//   Warnblinker
//   {
//     byte  >  Pin LED 
//     word  >  Millisekunden ON 
//     word  >  Millisekunden OFF
//     byte  >  Wiederholungen ON / OFF
//     word  >  Millisekunden Gesamtdauer Blinkzyklus     
//     word  >  Anzahl gew�nschter Zyklen (0 = Dauerblinker nach Start)
//   }
// 

class Warnblinker
{ 
  public:
    Warnblinker( byte, word, word, byte, word, word );
    void begin();
    void Start();
    void Stopp();
    void Run();
    
  private:  
    // Parameter
    byte _pin;      // Pin LED
    word _on;       // Millisekunden ON
    word _off;      // Millisekunden OFF
    byte _count;    // Wiederholung Einzel-Blinker 
    byte _cntback;  // (Backup Wiederholung Einzel-Blinker)
    word _repeat;   // Zyklus Wiederholen (0 > Dauerblinker)
    word _repback;  // (Backup Zyklus-Wiederholung)
    word _pause;    // Pause (Gesamt-Laufzeit 1 Zyklus)
    
    // Tempor�r
    boolean _cont;  // Dauer-Blinker?
    boolean _run;   // L�uft aktuelle Wiederholung
    boolean _state; // LED Status ON / OFF
    boolean _aktiv; // Gesamt-System aktiv?
    unsigned long _pre;        // Millis vorher
    unsigned long _akt;        // Millis aktuell
    
    // Millis von Zyklus / Pause
    unsigned long _milliseks;  
    unsigned long _zaehler;
    unsigned long _micros;
    
    // Private Methoden
    void ReStart();
    void PauseStart();
    void PauseRun();
};

// -----------------------------------------------------------------------
// Class "Taster"                                              KONSTRUKTOR
// Einfacher Taster, der "Down-Aktiv" abgefragt wird. 
//
// Eigenschaften / Methoden:
//   Gibt lediglich auf Anfrage einen einzigen "true"-Impuls zur�ck wenn gedr�ckt
//   Down-Aktiv = Negativ Flankengesteuert
//   Evtl. Prellen fest mit 25 mS �berbr�ckt
//
// Parameter:
//   Taster
//   (
//     byte > Pin-Nr. des Tasters
//   )
// 

class Taster
{
  public:
    Taster( byte );
    void begin();
    boolean KeyDown();
    				
  private:
    byte    _pin;
    boolean _down;
    word    _dbTime;
    boolean _lastDownState;
    unsigned long _lastDownTime;
};

#endif