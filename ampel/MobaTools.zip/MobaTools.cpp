
#include <MobaTools.h>
#include <Arduino.h>

// -----------------------------------------------------------------------
// Class "Ampelschaltung"                                  IMPLEMENTIERUNG
// Einfache Ampelschaltung f�r z.B. Modelleisenbahnen usw.
//
// Eigenschaften / Methoden:
//   - Nachtmodus auf manuelle Anforderung 
//   - Tagesmodus auf manuelle Anforderung 
//   - Fussg�nger-�berweg auf Gr�n nur wenn Anforderung vorliegt
//   - Fussg�nger-�berweg mit "Warten" kennzeichnet kommende Freigabe
//   - Wenn �berweg UND Nachtmodus angefordert wurde, wird alles dunkel geschaltet
//   - Im Nachtmodus blinkt nur gelbes Warnlicht
//   - Fussg�nger-Anforderung wird im Nachtmodus blockiert
//   - Nachtmodus (wenn angefordert) am Ende einer Gr�nphase
//
// Parameter:
//   Ampelschaltung
//   {
//     byte  >  Pin LED "Rot"   (Stra�e) / Mind. 10 Sek.
//     byte  >  Pin LED "Gelb"  (Stra�e) / Mind. 1 Sek.
//     byte  >  Pin LED "Gr�n"  (Stra�e) / Mind. 5 Sek.
//     byte  >  Pin LED (gelb)  (Signalisiert "Tag-/Nachtmodus" angefordert)
//     word  >  Sekunden Rot-Phase      
//     word  >  Sekunden RotGelb-Phase  
//     word  >  Sekunden Gr�n-Phase
//     word  >  Sekunden Gelb-Phase
//     byte  >  Pin LED "Wei�"  (Fu�g�nger "Warten")
//     byte  >  Pin LED "Rot"   (Fu�g�nger)
//     byte  >  Pin LED "Gr�n"  (Fu�g�nger)
//     byte  >  Pin LED (gelb)  (Signalisiert "Fug�nger-Modus" angefordert)
//   }
// 

Ampelschaltung::Ampelschaltung( byte pR,   byte pY,    byte pG,   byte paN,  \
                                word secR, word secRY, word secG, word secY, \
                                byte pfW,  byte pfR,   byte pfG,  byte paF   )
{
  _pinR      = pR;
  _pinY      = pY;
  _pinG      = pG;
  _pinAN     = paN;

  _secR      = (secR  < 10) ? 10 : secR  -1;  // mind. 10 Sek.
  _secRY     = (secRY <  1) ?  1 : secRY -1;  // mind.  1 Sek.
  _secG      = (secG  <  5) ?  5 : secG  -1;  // mind.  5 Sek.
  _secY      = (secY  <  1) ?  1 : secY  -1;  // mind.  1 Sek.

  _phase     = ROT;  
  _last      = START;  
  _modus     = true;   //  Start im Tagesmodus!
  _anford    = false;
  
  _pinWe     = pfW;
  _pinRo     = pfR;
  _pinGr     = pfG;
  _pinAF     = paF;
  
  _fussford  = false;
  _fussaktiv = false;
  _gruen     = false;
}

void Ampelschaltung::begin()
{
  pinMode( _pinR,  OUTPUT );    // Rot  (Auto)
  pinMode( _pinY,  OUTPUT );    // Gelb  "
  pinMode( _pinG,  OUTPUT );    // Gr�n  "
  
  pinMode( _pinWe, OUTPUT );    // Wei� (Fu�g�nger)
  pinMode( _pinRo, OUTPUT );    // Rot   "
  pinMode( _pinGr, OUTPUT );    // Gr�n  "
  
  pinMode( _pinAF, OUTPUT );    // Anforderung "Fu�g�nger"
  pinMode( _pinAN, OUTPUT );    // Anforderung "Modus" 
  
  digitalWrite( _pinR,  HIGH ); // Rot ON (Autos)
  digitalWrite( _pinRo, HIGH ); // Rot ON (Fu�g�nger)
}

void Ampelschaltung::Run()
{
  // Bearbeitung der einzelnen Ampelphasen, egal ob Tag- oder Nacht-Modus oder �berweg-Anforderung vorliegt
  if( _last != _phase )
    {
      _last = _phase;
      switch( _phase )
      {
        case ON      : digitalWrite( _pinR, LOW  ); // Nacht-Blinker ON
                       digitalWrite( _pinY, HIGH ); // wechselt sich mit OFF ab
                       digitalWrite( _pinG, LOW  );
                       _scount = 0;                 // im Sekunden-Takt
                       _next   = OFF;
                       break;
        
        case OFF     : digitalWrite( _pinR, LOW  ); // Nacht-Blinker OFF
                       digitalWrite( _pinY, LOW  ); // wechselt sich mit ON ab
                       digitalWrite( _pinG, LOW  );
                       _scount = 0;                 // im Sekunden-Takt
                       _next   = ON;
                       break;

        case ROT     : digitalWrite( _pinR, HIGH );
                       digitalWrite( _pinY, LOW  );
                       digitalWrite( _pinG, LOW  );
                       _scount = _secR;
                       _next   = ROTGELB;
                       break;
                       
        case ROTGELB : digitalWrite( _pinR, HIGH );
                       digitalWrite( _pinY, HIGH );
                       digitalWrite( _pinG, LOW  );
                       _scount = _secRY;
                       _next   = GRUEN;
                       break;
                       
        case GRUEN   : digitalWrite( _pinR, LOW  );
                       digitalWrite( _pinY, LOW  );
                       digitalWrite( _pinG, HIGH );
                       _scount = _secG;
                       _next   = GELB;
                       break;
                       
        case GELB    : digitalWrite( _pinR, LOW  );
                       digitalWrite( _pinY, HIGH );
                       digitalWrite( _pinG, LOW  );
                       _scount = _secY;
                       _next   = ROT;
                       break;
      }
    }
    
  // Millis-Counter... Je nach Phase, bei 0 n�chsten Modus bearbeiten
  if( millis() - _mS >= 1000 )
    {
      _mS = millis();
      if( _scount > 0 )    // Sekundenz�hler herunterz�hlen
        _scount--;
      else
        {
          if( _next == GELB && _anford == true ) // N�chste Phase Gelb UND Nachmodus angefordert ??
            { 
              // JA: Schaltet in Nachtmodus
              _phase     = ON;             
              _anford    = false;          
              _fussford  = false;          
              _fussblock = true;           
              digitalWrite( _pinAF, LOW ); 
              digitalWrite( _pinAN, LOW ); 
              digitalWrite( _pinWe, LOW ); 
              digitalWrite( _pinRo, LOW ); 
              digitalWrite( _pinGr, LOW );
            }
          else
            { 
              if( _next == OFF && _anford == true ) // N�chster Nachtblinker UND Tagesmodus angefordert ??
                {
                  // JA: Schaltet in Tagesmodus
                  _phase     = GRUEN;
                  _anford    = false;
                  _fussblock = false;
                  digitalWrite( _pinAF, LOW );  // Anforderung Fussg�nger OFF
                  digitalWrite( _pinAN, LOW );  // Anforderung Nachtmodus OFF
                  digitalWrite( _pinRo, HIGH ); // Fussg�nger zun�chst Rot
                }
              else
                {
                  // N�chste Ampelphase 
                  _phase = _next;        
                }
            }
        }
    }
    
  // Abfrage ob �berweg angefordert wurde 
  if( _fussford )
    {
      // Signalisiert "Warten"
      FussRun(); 
      
      if( RotPhase() )  // Wenn Auto-Rotphase begonnen hat, dann nach 2 Sekunden ...
        FussGruen();    // ... "Fussg�nger = Gr�n", bis 3 Sekunden vor Ende der Rotphase
    }                   
}

void Ampelschaltung::Nachtmodus()
{
  _modus  = !_modus;
  _anford = true;
  digitalWrite( _pinAN, HIGH );       //  Anforderung zeigen
}

void Ampelschaltung::Fussgaenger()
{
  if( _fussblock == false && _gruen == false )
    {
      // Anforderung Fu�g�nger, nur wenn NICHT durch Nachtmodus blockiert 
      // und NICHT aktuell aktiv
      _fussford  = true;
      _fussaktiv = true;
      digitalWrite( _pinAF, HIGH );   //  Anforderung zeigen
    }
}

void Ampelschaltung::FussGruen()
{
  digitalWrite( _pinAF, LOW  );       //  Anforderung l�schen
  digitalWrite( _pinWe, LOW  );
  digitalWrite( _pinRo, LOW  );
  digitalWrite( _pinGr, HIGH );       //  kannst loslaufen...
  _gruen = true;
}

byte Ampelschaltung::RotPhase()       // Abfrage bei "Fussg�nger-Modus"
{
  boolean result = false;
  if( _fussford )
    {
      // Gr�n f�r Fu�g�nger... erst nach 2 Sekunden Auto = Rot 
      if( _phase == ROT && _scount ==_secR -2 )
        result = true;
    }
  if( _gruen )
    {
      // 3 Sekunden vor "Ende Auto.Rot": Fu�g�nger auch wieder auf Rot
      if( _phase == ROT && _scount == 3 )
        {
          _gruen     = false;
          _fussford  = false;
          _fussaktiv = false;
          digitalWrite( _pinRo, HIGH );
          digitalWrite( _pinGr, LOW  );
        }
    }
  return result;
}

void Ampelschaltung::FussRun()
{
  // Weisses "Warten" blinkt
  if( _fussford && !_gruen )
    {
      if( millis() - _mf >= 500 )
        {
          _mf = millis();
          digitalWrite( _pinWe, !digitalRead(_pinWe) );
        }
    }
}



// -----------------------------------------------------------------------
// Class "Warnblinker"                                     IMPLEMENTIERUNG
// Blinker-/Flasher-Variante f�r beliebige Zwecke
//
// Eigenschaften / Methoden:
//   - Einsatz auf z.B. Modellbahnen f�r "Polizei auf Abruf"
//   - Herzschlag in einem Programm, gegen delay()...
//   - Mehrfach Impulsgeber wie z.B. ||__||__||__ oder |||_|||_|||_
//   - Einstellbar auf kontinuierliches Blinken gem�� Vorgabe
//   - Manueller Start zu einem beliebigen Zeitpunkt
//   - Manueller Stopp zu einem beliebigen Zeitpunkt
//
// Parameter:
//   Warnblinker
//   {
//     byte  >  Pin LED 
//     word  >  Millisekunden ON 
//     word  >  Millisekunden OFF
//     byte  >  Wiederholungen ON / OFF
//     word  >  Millisekunden Gesamtdauer Blinkzyklus     
//     word  >  Anzahl gew�nschter Zyklen (0 = Dauerblinker nach Start)
//   }
// 

Warnblinker::Warnblinker( byte pin, word on, word off, byte cnt, word pau, word rep )
{
  // Parameter-�bernahme, Basis-Inits
  _pin     = pin;
  _on      = on;
  _off     = off;
  _count   = cnt;
  _cntback = cnt;
  _pause   = pau;
  _repeat  = rep -1;
  _repback = rep -1;
  
  _run     = false;
  _state   = false;
  _cont    = ( rep == 0 ) ? true : false;  // Bei "Repeat == 0" Dauerblinker
}

void Warnblinker::begin()
{
  pinMode( _pin, OUTPUT );
}

void Warnblinker::Start()
{
  _repeat = _repback;  
  ReStart();
}

void Warnblinker::ReStart() // Intern wenn neuer Zyklus f�llig ist
{
  _count = _cntback;
  _run   = true;
  _state = false;
  digitalWrite( _pin, HIGH );  
}

void Warnblinker::Stopp() // Manueller Stopp
{
  _run    = false;
  _state  = false;
  _aktiv  = false;
  _repeat = 0;
  _count  = 0;
  digitalWrite( _pin, LOW );
}

void Warnblinker::Run() // Standard-Ablauf, egal on "aktiv" oder "inaktiv"
{
  if( _run == true )
    {
      // Verarbeitung ON-Zeit
      if( _state == false )
        {
          if( millis() - _pre >= _off )
            {
              _pre   = millis();
              _state = true;
              digitalWrite( _pin, _state );
            }
        }
      else
        {
          // Verarbeitung OFF-Zeit
          if( millis() - _pre >= _on )
            {
              _pre = millis();
              _state = false;
              digitalWrite( _pin, _state );
              
              // Impulsz�hler
              if( _count > 0 )
                _count--;
              if( _count == 0 )
                {
                  _run = false;
                  PauseStart();
                }
            }
        }      
    }
  else
    {
      // Pause bis n�chster Zyklus beginnt
      PauseRun();        
    }
}

void Warnblinker::PauseStart()
{
  _aktiv   = true;
  _zaehler = _milliseks;
  _micros  = micros();  
}

void Warnblinker::PauseRun()
{
  // Verarbeitung Pause wenn erforderlich
  if( _aktiv )
    { 
      if( micros() - _micros >= _pause * 1000UL )
        { 
          _micros = micros();
          if( _zaehler > 0 )
              _zaehler--;
          else
            {
              // Gesamt-Wiederholungen bearbeiten
              _aktiv = false;
              if( _repeat > 0 )
                {
                  if( _cont == false )
                    _repeat--;
                  ReStart();
                }
            }
        }
    }
}



// -----------------------------------------------------------------------
// Class "Taster"                                          IMPLEMENTIERUNG
// Einfacher Taster, der "Down-Aktiv" abgefragt wird. 
//
// Eigenschaften / Methoden:
//   Gibt lediglich auf Anfrage einen einzigen "true"-Impuls zur�ck wenn gedr�ckt
//   Down-Aktiv = Negativ Flankengesteuert
//   Evtl. Prellen fest mit 25 mS �berbr�ckt
//
// Parameter:
//   Taster
//   (
//     byte > Pin-Nr. des Tasters
//   )
// 

Taster::Taster( byte pin )
{
  if( pin > 54 ) 
    pin = 0;
    
  _pin           = pin;
  _dbTime        = 25;  // derzeit fest auf 25 mS
  _down          = false;
  _lastDownTime  = 0;
  _lastDownState = false;
}

void Taster::begin()
{
  pinMode( _pin, INPUT_PULLUP );
}

boolean Taster::KeyDown()
{
  boolean result    = false;
  boolean currState = !digitalRead( _pin );
  
  // �berbr�ckung der Prellzeit
  if( currState != _lastDownState ) 
    _lastDownTime = millis();
  if( ( millis() - _lastDownTime ) >= _dbTime )
    {
      if( currState != _down )
        {
          _down = currState;
          // Einmalige R�ckgabe von "true" auf Anfrage wenn Taste gedr�ckt
          if( _down  )
            result = true;
        }
    }  
  _lastDownState = currState; 
  
  return result;
}
